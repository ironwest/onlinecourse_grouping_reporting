library(tidyverse)

#データの読み込み
dat <- read_csv("2018-52-teiten-tougai.csv",
                col_names = FALSE, 
                locale = 
                  locale(encoding = "shift-jis"))

#一時保管
temp_title <- dat[[1,1]]
temp_sakusei_date <- dat[[2,2]]

#削除
dat2 <- dat %>% slice(-1,-2)

#病名列作成
dat3 <- dat2 %>% 
  mutate(dxname = 
           if_else(
             !str_detect(X1,"[都道府県]$|^総数$"),
             X1,NA_character_
           )
  ) %>% 
  fill(dxname, .direction = "down")

#列名を作成
coln <-  dat3 %>% slice(2:3)
veccol <- coln %>% 
  t() %>% 
  as_tibble(.name_repair = "unique") %>% 
  mutate(fincolname = str_c(...1,"_",...2)) %>% 
  pull(fincolname)

veccol[1] <- "prefecture"
veccol[108] <- "dxname"

#列名行を削除
dat4 <- dat3 %>% 
  filter(str_detect(X1,"[都道府県]$"))

#列名を設定
colnames(dat4) <- veccol
#列の並び替え
dat4 <- dat4 %>% select(dxname, prefecture, everything())

#縦持ちデータに
dat5 <- dat4 %>% 
  pivot_longer(cols = -c(dxname, prefecture),
               names_to = c("weeknum","type"),
               values_to = "value",
               names_sep = "_")

#総数列の作成
dat6 <- dat5 %>% 
  group_by(dxname, prefecture, type) %>% 
  mutate(total = if_else(weeknum == "総数",
                         value,
                         NA_character_)) %>% 
  fill(total)


dat6 <- dat6 %>% ungroup()

#週数を数字へ
dat7 <- dat6 %>% 
  filter(weeknum != "総数") %>% 
  mutate(weeknum  = str_extract(weeknum,"\\d+")) %>% 
  mutate(weeknum  = as.numeric(weeknum))

#おしまい
dat8 <- dat7 %>% 
  mutate(data_title = temp_title,
         data_sakusei = temp_sakusei_date2)

dat8 <- dat8 %>% 
  mutate(value = as.numeric(value))