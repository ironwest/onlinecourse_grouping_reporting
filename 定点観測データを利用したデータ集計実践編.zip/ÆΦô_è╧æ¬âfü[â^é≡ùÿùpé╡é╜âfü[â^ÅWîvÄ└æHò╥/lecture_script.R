##lec01:セクションの導入-------------
#スライド1-4

##lec02:データのダウンロード-----------------


#lec:ファイルのインポート---------

#ここまででご説明したファイルの
#ダウンロードは済んでいますか?
#
#ここからは、ダウンロードしてきたデータを加工して、
#Tidyなデータに変換する方法を説明していきます。


# まずは、ファイルをインポートしましょう
# ここでは、.csvファイルをインポートするので、
# readr::read_csvを利用します。

library(tidyverse)

dat <- read_csv("2018-52-teiten-tougai.csv")

# 大量の警告がでていますね。

dat

#しかも表示をしようとするとエラーがでています。

# 解決していきましょう。
# まずは、最初の警告ですが、Missing column namesで
# X2(2列目)から延々と「列名がない」と警告されています

# これが出る理由は簡単で、
# ちょっとcsvファイルを見てみましょう
# 
# このように1行目の1列目のデータが
# 「報告数・定点当り報告数、
# 　　疾病・週・都道府県・性別
# 　　（１週から当該週までの報告数・
# 　　　定点当たり報告数とそれらの累積）
# 　　　(総数)」
# 
# こんな感じのタイトルになっています
# 
# そのため、2列目以降が空白となっているため
# コラム名がありませんと怒られたのです。
# 
# 2行目も1列目が
# 　「2018年52週(12月24日～12月30日)」
# 2列目が
# 　「2019年01月07日作成」
# となっており、
# 
# 3行目も1列目が
# 　「インフルエンザ」
# 
# となっており、まともに列名として利用できる
# 行は、4行目くらいでしょうか?
# 
# このようなケースでは、基本的には列名を
# お手軽に登録することはあきらめます。
# 
# 「すべてデータ」として読み込んでから、
# 「後から列名を作成する」という作戦で
# 処理していきましょう。
# 

# すべてをデータとして読み込むのは簡単です。
# col_namesの設定をFALSEとしてあげることで、
# コラム名なしでcsvファイルをすべてデータと
# して読み込むことができます。

dat <- read_csv("2018-52-teiten-tougai.csv",
                col_names = FALSE)

dat

# 文字化けしているので
# 文字コードの設定を変えておきましょう。

dat <- read_csv("2018-52-teiten-tougai.csv",
                col_names = FALSE, 
                locale = 
                  locale(encoding = "shift-jis"))

dat

#次の動画では、
#　データのタイトル(1行目)
#　作成日(2行目)
#をとりだす方法について考えていきます。

#lec:1行目と2行目の処理--------------------
dat

#の1行目と2行目の1列目のデータを取り出してみましょう。
#方法はいくつかあります。


# 方法1:[[]]を利用した指定方法

#tibble[[列番号,行番号]]という指定の行い方で
#要素として取り出すことができます。
dat[[1,1]]
dat[[2,1]]; dat[[2,2]]

#ということで、
temp_title <- dat[[1,1]]
temp_sakusei_date <- dat[[2,2]]

temp_title
temp_sakusei_date

#方法2:dplyr(slice,pull)を利用する方法
#
#dplyrのsliceは行番号の指定で、
#その行をtibble形式で抜き出すことができます。
#
#また、pull関数は、列名の指定か、列番号の指定で
#ベクトルとしてその列を抜き出すことができます。
#なので、

temp_title <- dat %>% slice(1) %>% pull(1)
temp_sakusei_date <- dat %>% slice(2) %>% pull(2)

temp_title
temp_sakusei_date

#いかがでしょうか?
#目的とする行番号、
#列番号の要素を簡単にとりだすことができました
#この取り出したデータがあれば、後々mutateを利用して列を
#作成することができます。

#本動画の最後に、temp_sakusei_dateを
#日付型に変更しておきましょう。

temp_sakusei_date2 <- 
  lubridate::parse_date_time(
    temp_sakusei_date,"ymd",tz = "Asia/Tokyo")

temp_sakusei_date2

#あるいは

temp_sakusei_date2 <- 
  lubridate::ymd(temp_sakusei_date,tz="Asia/Tokyo")

temp_sakusei_date2

#ここで作成したtemp_変数は最後のほうで
#データにくっつけます。いったん忘れましょう。
#もう1行目と2行目は必要ないので消しておきます。

dat2 <- dat %>% slice(-1,-2)
dat2
#次は、病名の抽出方法を考えていきます。


#lec:病名の抽出方法------------------------
#この動画では、1列目のデータである
dat2$X1

#の中から「インフルエンザ」(1行目)、
#「RSウイルス感染症」(53行目)
# 等を都道府県の名前の中から抽出する方法を考えていきます。

#目標とする形は、都道府県と病名を完全に別の列に分ける
#ことです。「入門コース」で解説した知識で実現できるので
#「問題なくできる」という方はこの動画を飛ばしてもらって
#も構いません。
#
#でははじめていきます。

#まずは、

tgt <- dat2$X1
tgt

#の中から病名がある位置を割り出します。
#そのためには、正規表現を利用しましょう

unique(tgt)

#でみていくと、
#都道府県はすべて「都」「道」「府」「県」
#のいずれかで終わっています。
#また、病気の名前が都道府県のいずれかの文字で
#終わっているものはありません。

#そのため、

str_detect(unique(tgt),"[都道府県]$")

#で「都道府県」で終わる文字列に
#TRUE/FALSEを付与することが可能となります。

#これを利用して、次のように処理をすすめることで、
#病名と都道府県を分けて列に収納できます。

dat2 %>% 
  select(X1) %>% 
  mutate(temp_tf = !str_detect(X1,"[都道府県]$"))

#総数という文字列も含まれていました。
#これもとりあえず、都道府県と同じ扱いにして
#分けていきましょう


tempdat <- dat2 %>% 
  select(X1) %>% 
  mutate(temp_tf = !str_detect(X1,"[都道府県]$|^総数$")) %>% 
  mutate(dxname = if_else(temp_tf,X1,NA_character_))

View(tempdat)

#いかがでしょうか?
#病名が取り出せていますね?

#これと、fillを利用することで、病名列が完成します。
#実際のdat2に適応してみてください。
#
#
#
#
#
#
#できましたか?こんな処理ができていればOKです

tempdat <- dat2 %>% 
  select(X1:X3) %>% 
  mutate(dxname = 
           if_else(
             !str_detect(X1,"[都道府県]$|^総数$"),
             X1,NA_character_
             )
         ) %>% 
  fill(dxname, .direction = "down")

View(tempdat)

#この形にできたのであれば、
dat3 <- dat2 %>% 
  #select(X1:X3) %>% 
  mutate(dxname = 
           if_else(
             !str_detect(X1,"[都道府県]$|^総数$"),
             X1,NA_character_
             )
         ) %>% 
  fill(dxname, .direction = "down")

View(dat3)


#疾患と疾患の間のNAで囲まれている部分の
#行は必要なくなるので消してしまいたいところですが
#列名が含まれているため、次の動画では
#X1、X2という名前から列名に変換できるように
#列名を抽出する方法について考えていきましょう

#lec:列名の抽出のための確認---------------------------------
#では続いて、

dat3 %>% select(1:5)

#から、列名を抽出していきましょう
#
#列名が含まれているのは、2行目と3行目です。

coln <- dat3 %>% slice(2,3)

View(coln)

#に見える形でそれぞれ「総数」か
#「定当」(定点当たり報告数)で
#第XX週を分けています(総数もあり)

#一応
dim(dat3)
#で935行×108列あるので

View(dat3 %>% select(103:108))

#でわかるのように、X107がすべて同一か見ておきましょう
#dat3$X107の数字以外の文字列を抜き出すことできますか?

tvec <- dat3$X107
tvec[!str_detect(tvec,"^\\d+$|\\d+\\.\\d+")]

tvec[!str_detect(tvec,"^\\d+$|\\d+\\.\\d+")] %>% 
  unique()

#ということで、52週　定当　という文字列しか入っていない
#のですべての疾患でX107の列方向は52週定当というデータ
#であるということがわかりました。
#
#これだけでチェック終わらせてもよいですが、
#今回は、もっと確証をもてるチェック方法を考えて
#みましょう。次の動画からはチェック方法の考え方
#について解説していきます

#lec:スライド列のチェック方法---------
#
#
#lec:列のチェックの実践1:行方向に抽出--------
#
#それでは実践していきましょう。
#まずは、スライドのイメージで解説した通り、
#スライドで列毎のラベルを付けている行をこの動画
#では抽出していきます。
#
#抽出を行うためには、which関数というものを利用します
#which関数は、例えば、
        #1,2,3,4,5,6         
tgt <- c(T,F,T,T,F,T)

#というロジカルベクトルがあるとして、

base::which(tgt)

#こんな感じで、Tが入っている位置を返してくれます。

which(c(NA,T,NA,F,F,T))

#NAが入っていても、ちゃんと動きます。
#それでは、このwhich関数を利用して

dat3 %>% select(1:3) %>% View()

#病名の後の2行の位置を調べてみましょう。
#今回の場合は、X2の位置で考えていきます。
#データを見た感じ、「数字以外」「NA以外」で
#確定して良さそうなので、

tgt <- dat3$X2
!str_detect(tgt,"\\d+")  #数値以外
!is.na(tgt)　　　　　　　#NA以外

which(!str_detect(tgt,"\\d+") & !is.na(tgt))
#数値とNA以外の位置が取得できました。

#取り出してみましょう

dat3 %>% 
  slice(which(!str_detect(tgt,"\\d+") & !is.na(tgt))) %>% 
  View()

#いかがでしょうか?
#スライドで説明した行のとりだしができていますね？
#見た感じでは、すべて、同じ内容で問題なさそうですが、
#次の動画で一応、列方向ですべて問題ないかのチェックをして
#から次に進みましょう。
#
#lec:列のチェックの実践2:列方向に抽出―――――――――
#それでは、ひとつ前の動画で抜き出したデータ
#をチェックします。
#
#自分でできる!という方はやってみてください。

checkthis <- dat3 %>% 
  slice(which(!str_detect(tgt,"\\d+") & !is.na(tgt)))

checkthis %>% 
  map(unique) %>% 
  enframe(value = "value") %>% 
  mutate(length = map_int(value, length)) %>% 
  filter(length != 2)

#ということで、X1とdxname以外はすべて要素が2つ
#みたいなので、問題ないと判断できます。
#
#され、ここで何をしたか理解できますか?
#map関数の利用方法は、作業自動化入門のところで
#解説をつっこんで行っているので、mapの機能の詳細
#はそちらで確認ください。
#(mapはかなり踏み込んだ解説が必要なため、ここでは
#繰り返せません。)
#
#1行ずつ動作を確認してみましょう。
#まずは、mapの挙動からです。
#mapは、繰り返し処理を簡単に記載できる
#関数でしたね?　なので、

checkthis %>% 
  map(unique)

#を行うと、次のような結果を返す処理が行われます。
res <- list()

res[[colnames(checkthis)[[1]]]] <- unique(checkthis %>% pull(1))
res[[colnames(checkthis)[[2]]]] <- unique(checkthis %>% pull(2))
res[[colnames(checkthis)[[3]]]] <- unique(checkthis %>% pull(3))
res[[colnames(checkthis)[[4]]]] <- unique(checkthis %>% pull(4))
res[[colnames(checkthis)[[5]]]] <- unique(checkthis %>% pull(5))

res

#どうでしょうか?
#checkthis tibbleの列がすべてunique関数に放り込まれて、
#その結果がnamed list(名前がついたリスト)の形で返ってきます。

checkthis %>% 
  map(unique)

#さらに、enframe関数にnamedlistを放り込むと、tibble化ができます。

listexample <- list(
  a = 1:5,
  b = 5:9
)

listexample

enframe(listexample)

#ちなみに、as_tibbleに入れると、

as_tibble(listexample)

#こういうデータの持ち方になります。

#さて、あとは

checkthis %>% 
  map(unique) %>% 
  enframe(value = "value") %>% 
  mutate(length = map_int(value, length))

#lengthという名前の列をmutateでつくり、
#map_intで、value列の中に保存されているchrベクトルに対して、
#length()を適応していくことで
#「すべての列のuniqueな値の数を数える」
#ということが実現できました。
#
#ちんぷんかんぷんでしたか?
#このtibbleの中でmap関数を適応する方法は
#使いこなせるとかなり強力な武器になるので、
#この時点で何が起こったかわからない方には、
#次の動画でイメージを解説しておきます。
#(自動化入門でmap関数の挙動を理解していてのみこめた
#という方は飛ばしていただいて構いません。)
#
#lec:スライド:tibble内でのmap関数の利用をイメージで――――――

#lec:列名の設定---------
#それでは、この動画からは列名を設定する方法を実践していきます。
#まずは、列名を再度取得しましょう

coln <-  dat3 %>% slice(2:3)


#この、colnですが2行のデータです。
#これを1行のコラム名とするためには、次のように処理して
#みましょう

coln %>% 
  t() %>% 
  as_tibble(.name_repair = "unique")

#t()で行列を入れ替えて、as_tibbleで再度tibbleに戻します。
#そうすると、2列のデータとなります。あとは、

coln %>% 
  t() %>% 
  as_tibble(.name_repair = "unique") %>% 
  mutate(fincolname = str_c(...1,"_",...2))


coln %>% 
  t() %>% 
  as_tibble(.name_repair = "unique") %>% 
  mutate(fincolname = str_c(...1,"_",...2)) %>% 
  pull(fincolname)

#あとは、この108個の文字列ベクトルを適応するだけです。

veccol <- coln %>% 
  t() %>% 
  as_tibble(.name_repair = "unique") %>% 
  mutate(fincolname = str_c(...1,"_",...2)) %>% 
  pull(fincolname)

View(veccol)

#ただし一つ目は都道府県名なので、置き換えておきましょう

veccol[1] <- "prefecture"

#また、108個目の最後の要素が
#インフルエンザ_インフルエンザとなっているので
#こちらも、置き換えておきましょう

veccol[108] <- "dxname"

#それでは作成した列名を適応していきます
#ただ、その前に、dat3のいらないデータを削除しておきましょう

dat4 <- dat3 %>% 
  filter(str_detect(X1,"[都道府県]$"))

colnames(dat4) <- veccol

dat4 <- dat4 %>% select(dxname, prefecture, everything())

View(dat4)

#次の動画では、このデータを
#縦持ちのデータに変換していきます。
#
#lec:データの縦持ちへの変換1-------------------
#スライド44-

#スライドでお示しした変換自体は
#tidyrの関数を利用すれば非常に簡単に実施できます

dat4 %>% 
  pivot_longer(cols = -c(dxname, prefecture),
               names_to = c("weeknum","type"),
               values_to = "value",
               names_pattern = "(.+)_(.+)") %>% 
  View()

#いかがでしょうか?
#pivot_longerという関数を利用すれば、
#複雑な列名も一回の関数の適応で縦持ちデータ
#に変換できます。
#
#「入門コース」を作成した時点では、この
#pivot_longer関数が存在していなかったため
#gatherとspread関数でデータの縦持ち、横持ち
#の変換を説明していましたが
#
#pivot_longer <-> gather
#pivot_wider  <-> spread
#
#という対応でほぼ同じ使い方ができます。
#ただし、pivot_***系の関数は
#ここでお見せしたように、複雑な列名を
#処理するという機能があります。
#
#次の動画では、今回実施したpivot_longer関数が
#どのように働いているのか、pivot_longerを
#使わずに解説を行っていきます。

#lec:データの縦持ちへの変換2-------------------
#
#一つ前の動画では、

dat4 %>% 
  pivot_longer(cols = -c(dxname, prefecture),
               names_to = c("weeknum","type"),
               values_to = "value",
               names_pattern = "(.+)_(.+)")

#この変換を実施しました。
#この動画では、この変換をpivot_longerを使わずに
#行っていきます。

dat4 %>% 
  gather(-dxname, -prefecture,key = key, value = value)

#gather関数で縦持ちデータに変換できました。
#後は、key列が<週数>_<報告/定当>に分かれている
#のでこの列を分割すればpivot_longerと同じ結果
#になります

#分割するには、separate関数等もありますが、
#ここでは、pivot_longerと同じ指定方法をとる
#tidyr::extractを利用します。
#
#extractの使い方としては、

temp <- tibble(a = c("犬がワンワンとなく",
                     "猫がにゃーにゃ―となく",
                     "トラがガオーッ!とほえる",
                     "サルはウッキッキーと嬉しそう"))

temp

#このようなデータがあったとして、

tribble(
  ~animal, ~say,
  "犬"    , "ワンワン",
  "猫"    , "にゃーにゃー",
  "トラ"    , "ガオーッ！",
  "サル"    , "ウッキッキー"
)

#こんな感じのデータへと変換するときにも利用できます。

temp

temp %>% 
  extract(col   = a, 
          into  = c("animal","say"),
          regex = "(.+)[がは](.+)と",
          remove = TRUE)

#いかがでしょうか?
#変換したい列を持つデータをextractにパイプで入れます
#その中で、
# colで、変換したいコラム名を指定
# intoで、変換後に作りたい新しい列名を指定
# regexで、colで指定した文字列に対して、()で指定した
# 　正規表現を記載してあげると、()で拾える文字列が
# 　intoに保存されるという形になります。
# 　
# 今回利用した正規表現は、
# 
# "( .+ )[がは](     .+     )と"
# " 犬    が    ワンワン     となく"
# " 猫    が    にゃーにゃ―  となく"
# " トラ  が    ガオーッ!    とほえる"
# " サル    は  ウッキッキー と嬉しそう"
# 
# こんな感じになります。
# regexで指定した()がうまく拾われて
# 列名になっていることが見えますか?

# それでは本題にもどりましょう
dat5 <- dat4 %>% 
  gather(-dxname, -prefecture,key = key, value = value)

dat5$key %>% unique()

#このkeyに入っている文字列をうまくとらえる
#正規表現は、
#
#"^(.+)_(.+)$"
#
#となります。

dat4 %>% 
  gather(-dxname, -prefecture,key = key, value = value) %>% 
  extract(col = key, into = c("weeknum","type"),
          regex = "^(.+)_(.+)$")

#わかれました!

dat4 %>% 
  pivot_longer(cols = -c(dxname, prefecture),
               names_to = c("weeknum","type"),
               values_to = "value",
               names_pattern = "(.+)_(.+)")

#同じ結果ですね。
#実は、separateもpivot_longerに内包されているので

dat5 <- dat4 %>% 
  pivot_longer(cols = -c(dxname, prefecture),
               names_to = c("weeknum","type"),
               values_to = "value",
               names_sep = "_")

#names_patternでもnames_sepでもうまい具合に
#分けてくれるのでぜひ活用してみてください!

dat5

#lec:週数の「総数」を分離する-------------------

#ここまでの過程で縦持ちデータへの
#変換が終わりました。
#続いて、最初のスライドでお示しした目的
#の形に整えて、分析に適した形に型変換を
#行っていきましょう。

#dat5のweeknumの「総数」をどうしましょうか?
#
#週数のデータではないので、これは別の列にしましょう
#色々な方法はありますが、ここではgroup_by関数
#を利用してみましょう。

dat6 <- dat5 %>% 
  group_by(dxname, prefecture, type) %>% 
  mutate(total = if_else(weeknum == "総数",
                         value,
                         NA_character_)) %>% 
  fill(total)

#この動作わかりましたか?
#単純にfillをしてしまうと、


dat5 %>% 
  #group_by(dxname, prefecture, type) %>% 
  mutate(total = if_else(weeknum == "総数",
                         value,
                         NA_character_)) %>% 
  fill(total) %>% 
  View()

#このように、総数の中に、報告と定当の両方があるので
#定当のデータだけが下方向に埋められてしまいます。
#
#ここで、fillの前にgroupby関数を利用して、
#病名別、県別、種類別まで分けることで

dat5 %>% 
  filter(dxname == "インフルエンザ",
         prefecture == "北海道",
         type == "報告") %>% 
  mutate(total = if_else(weeknum == "総数",value,NA_character_)) %>% 
  View()

#や

dat5 %>% 
  filter(dxname == "インフルエンザ",
         prefecture == "北海道",
         type == "定当") %>% 
  mutate(total = if_else(weeknum == "総数",value,NA_character_)) %>% 
  View()

#というデータに対してfillを適応できます。
#
#lec:週数の数字化とungroup()-------------------
#総数を分けることができたので
# 行を除去して
# 週数を数字で保存して
#おきましょう

dat6 %>% select(weeknum) %>% 
  filter(weeknum != "総数") %>% 
  mutate(weeknum2 = str_extract(weeknum,"\\d+"))

#と、その前にここでweeknumのみを表示して
#変換結果を比較してみようとしてみましたが、
#Adding missing grouping variables: 
#　　　　　`dxname`, `prefecture`, `type`
#　　　　　
#という表記がでて、select(weeknum)としたはずなのに
#weeknum列だけになっていません。
#
#これは、

dat6

#> dat6
# A tibble: 89,676 x 6
# Groups:   dxname, prefecture, type
#   [1,692]
#
#と表記されているように、現在dat6には、
#group_by関数の効果がのこっています。
#
#効果が残っている状態では、group_by関数
#で指定した変数を除去しようとすると
#このような結果になります
#
#なので、group化が必要なくなった場合は、

dat6 <- dat6 %>% ungroup()

dat6

#としておくと問題解決です。


dat6 %>% select(weeknum) %>% 
  filter(weeknum != "総数") %>% 
  mutate(weeknum2 = str_extract(weeknum,"\\d+")) %>% 
  mutate(weeknum2 = as.numeric(weeknum2))

# これで数字にできますね?

dat7 <- dat6 %>% 
  filter(weeknum != "総数") %>% 
  mutate(weeknum  = str_extract(weeknum,"\\d+")) %>% 
  mutate(weeknum  = as.numeric(weeknum))

#lec:データの完成と課題-------------------
#お疲れさまでした。
#現在できている

dat7

#にセクションの最初のほうで
#取り出しておいた変数の値を
#付け加えればデータの完成です。

#一応、振り返ると、次のような
#変数を作成していましたね？
temp_title <- dat[[1,1]]
temp_sakusei_date <- dat[[2,2]]
temp_sakusei_date2 <- 
  lubridate::parse_date_time(
    temp_sakusei_date,"ymd",tz = "Asia/Tokyo")

#これを足しておきます。
dat8 <- dat7 %>% 
  mutate(data_title = temp_title,
         data_sakusei = temp_sakusei_date2)

#後は、列を各々適切な型に変換しておきましょう
dat8 <- dat8 %>% 
  mutate(value = as.numeric(value))

#どうでしょうか？
#これで、最初のスライドで
#お示しした形への変換ができましたね?
#(まあ、data_title、data_sakusei列は
#必要でないかもしれませんが・・・)

#この形にしておくことで、例えば、
#北海道のデータを見たいときには、
dat8 %>% 
  filter(prefecture=="北海道") %>% 
  filter(type == "報告") %>% 
ggplot() +
  geom_point(aes(x = weeknum, 
                y = value,
                color=dxname)) +
  geom_line(aes(x = weeknum,
                 y = value,
                color = dxname,
                 group=dxname))

#こんな感じで、
#病名をリスト化してフィルターをかけることで
diseaselist <- dat8$dxname %>% unique()

dat8 %>% 
  filter(prefecture=="北海道") %>% 
  filter(type == "報告") %>% 
  filter(dxname %in% diseaselist[4:8]) %>% 
  ggplot() +
  geom_point(aes(x = weeknum, 
                 y = value,
                 color=dxname)) +
  geom_line(aes(x = weeknum,
                y = value,
                color = dxname,
                group=dxname))
#疾患毎の推移を確認したり、

#都道府県を選択的して、
dat8 %>% 
  filter(prefecture %in% c("北海道","沖縄県")) %>% 
  filter(type == "定当") %>% 
  filter(dxname %in% diseaselist[c(5,18)]) %>% 
  ggplot() +
  geom_point(aes(x = weeknum, 
                 y = value,
                 color=dxname)) +
  geom_line(aes(x = weeknum,
                y = value,
                color = dxname,
                group=dxname)) +
  facet_wrap(~prefecture)

#感染性腸炎が沖縄では通年で起こっているけど、
#北海道では季節性がありそう

#等の分析が簡単にできるようになりました。
#この分析、最初に取り込んだままでは
#できないといことをご理解いただけるでしょうか?

#課題です。
#ここまで学んだことを利用して、
#同じ形のデータを最後の形に加工する関数を作成してください。

#lec:課題解答―スクリプトの関数化------------

#どうでしょうか?
#できましたか?

#ここまでのスクリプトを再度もってきて、
#関数にすると、次のような形になります。
#
#関数を作成する際は、function()の中に、
#今回の場合は処理したいファイルの場所を、
#function(){}の最後に、処理し終わった
#データをreturn(data)とすることを
#忘れないようにしてください。

library(tidyverse)

process_teiten <- function(filepath){
  #データの読み込み
  dat <- read_csv(filepath,
                  col_names = FALSE, 
                  locale = 
                    locale(encoding = "shift-jis"))
  
  #一時保管
  temp_title <- dat[[1,1]]
  temp_sakusei_date <- dat[[2,2]]
  
  #削除
  dat2 <- dat %>% slice(-1,-2)
  
  #病名列作成
  dat3 <- dat2 %>% 
    mutate(dxname = 
             if_else(
               !str_detect(X1,"[都道府県]$|^総数$"),
               X1,NA_character_
             )
    ) %>% 
    fill(dxname, .direction = "down")
  
  #列名を作成
  coln <-  dat3 %>% slice(2:3)
  veccol <- coln %>% 
    t() %>% 
    as_tibble(.name_repair = "unique") %>% 
    mutate(fincolname = str_c(...1,"_",...2)) %>% 
    pull(fincolname)
  
  veccol[1] <- "prefecture"
  veccol[108] <- "dxname"
  
  #列名行を削除
  dat4 <- dat3 %>% 
    filter(str_detect(X1,"[都道府県]$"))
  
  #列名を設定
  colnames(dat4) <- veccol
  #列の並び替え
  dat4 <- dat4 %>% select(dxname, prefecture, everything())
  
  #縦持ちデータに
  dat5 <- dat4 %>% 
    pivot_longer(cols = -c(dxname, prefecture),
                 names_to = c("weeknum","type"),
                 values_to = "value",
                 names_sep = "_")
  
  #総数列の作成
  dat6 <- dat5 %>% 
    group_by(dxname, prefecture, type) %>% 
    mutate(total = if_else(weeknum == "総数",
                           value,
                           NA_character_)) %>% 
    fill(total)
  
  
  dat6 <- dat6 %>% ungroup()
  
  #週数を数字へ
  dat7 <- dat6 %>% 
    filter(weeknum != "総数") %>% 
    mutate(weeknum  = str_extract(weeknum,"\\d+")) %>% 
    mutate(weeknum  = as.numeric(weeknum))
  
  #totalを数字へ
  dat7 <- dat7 %>% 
    mutate(total = as.numeric(total))
  
  #おしまい
  dat8 <- dat7 %>% 
    mutate(data_title = temp_title,
           data_sakusei = temp_sakusei_date2)
  
  dat8 <- dat8 %>% 
    mutate(value = as.numeric(value))
  
  return(dat8)
  
}

#実行してみましょう
dat18 <- process_teiten("2018-52-teiten-tougai.csv")

dat18

#できました!

#この関数、新しいデータでも動くか確認してみましょう。
#2019年52週のデータ
#https://www.niid.go.jp/niid/ja/data/9289-idwr-sokuho-data-j-1952.html
#を適応してみると、

dat19 <- process_teiten("2019-52-teiten-tougai.csv")

View(dat19)

#できてますね。
#これで、

dat <- bind_rows(
  dat18 %>% mutate(yr = "2018"),
  dat19 %>% mutate(yr = "2019")
)

dat %>% 
  filter(dxname == "インフルエンザ",
         prefecture == "東京都",
         type == "報告") %>% 
  ggplot() + 
  geom_point(aes(x = weeknum, y = value, color = yr))+
  geom_line (aes(x = weeknum, y = value, 
                 color = yr, group = yr))

# 2019年と2018年の東京都でのインフルエンザの流行
# について可視化することができました
# 
# お疲れさまでした。
# データの取得と加工はこれで完成です。
# 次の動画からはいよいよ、グループ集計を利用した
# 分析の実行と動的レポートの作成を行って
# いきます。
# その前に!
#
# 出来上がったデータを保存しておきましょう。

dekiagari <- bind_rows(
  dat18 %>% mutate(yr = "2018"),
  dat19 %>% mutate(yr = "2019")
)

write_rds(dekiagari,"data/dekiagari.rds", compress="gz")


#lec:グループ内での前後比較:スライドでのイメージ-------
#slide50-

#lec:グループ内での前後比較:Rでの実践――――――――――――

#さて、ここからは、グループ集計を利用した
#分析方法を考えていきましょう。
#まずは、今回のような時系列データ必要となる操作として、
#「1時点前や1時点後との比較」
#を行う方法を実践していきましょう

library(tidyverse)

#lecture_script.Rで作成したデータを読み込みます
dat <- read_rds("data/dekiagari.rds")

dat2 <- dat %>% select(yr, dxname, prefecture,
                       weeknum, type, value)
#まずは、スライドで行った計算を実施します。
View(dat2)

buf <- dat2

dat2 <- buf %>% 
  group_by(yr, dxname,prefecture,type) %>% 
  arrange(type)

#group_byだけでは見た目が変わらないので
#arrange(type)として並べかえも行いました

dat2 <- buf %>% 
  group_by(yr, dxname,prefecture,type) %>% 
  arrange(type) %>% 
  mutate(lag_val = lag(value),
         lead_val = lead(value))

#lagは「遅れる」というような
#　　　マイナスイメージ -> 下にずらす
#leadは「リードする」というような
#　　　プラスイメージ   -> 上にずらす

# というイメージをもつとどっちがどっち
# 方向か覚えやすいかもしれません
# 
# データをみてみましょう。
# lag_valはvalueの値が下にずらされて
# 入れられており、１番目は前の値が
# ないのでNAとなっています。
# 
# lead_valも同様で、
# valueの値が上にずらされており、
# 少しスクロールして
# グループの境目までいくと、
# 次の値がないので、
# NAとなっています。
# 
# ところで、もし次のように、group_by
# を入れずにlagとleadを利用したら
# どうなるか想像できますか?
# やってみましょう

dat2 <- buf %>% 
  #group_by(yr, dxname,prefecture,type) %>% 
  arrange(type) %>% 
  mutate(lag_val = lag(value),
         lead_val = lead(value))

#なんとなくうまくいっていそうにも思いますが
#53行目を見てみてください。
#北海道から青森県への境ですが、
#group_byを入れたときにあった
#欠損値が入っておらず、
#青森県の第1週の前の値が
#北海道の第53週の値となっており、
#不適切です。
#(あるいは、北海道の第53週の次の
#値が青森県の第1週となっています)

#このように、group_byを適切に利用する
#ことで、ずらして集計するような
#場合にも適切な区切りでもって計算を
#すすめることができますので、
#便利です。
#
#では、lagとleadの計算ができたので
#プチ課題です。
#
#スライドで解説した方法を再現して、
#diffという名前の列を作成してみてください。

#lec:プチ課題回答---------

# できましたか?
# スライド通りでこんな感じです。

dat2 <- buf %>% 
  group_by(yr, dxname,prefecture,type) %>%
  arrange(type) %>% 
  mutate(lag_val = lag(value)) %>% 
  mutate(diff = value - lag_val)


#この差の列を利用すると、
#
dat2 %>% 
  filter(dxname == "インフルエンザ",
         prefecture %in% c("沖縄県","北海道"),
         type == "報告") %>% 
  ggplot() +
  geom_col(aes(x = weeknum, 
               y = diff, 
               fill = prefecture),
           position = "dodge") +
  facet_wrap(~yr)

#こんな表現が可能になったりします。
#
#lagとleadは、しっかりとしたイメージが
#もてていないと、group_byと併用したとき
#に、NAが発生したり、少し
#他の関数と動作が違うように感じられること
#があるので、丁寧に説明してみました。
#
#それでは、次の動画からは、
#好きな疾患、好きな都道府県を選んで
#レポートを生成できる
#parametarized reportの作成について
#解説を行っていきます