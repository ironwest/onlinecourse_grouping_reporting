
##lec01:日本の白地図データの取得---------

# 本コースのメインテーマではありませんが、
# レポートに日本の白地図を表示しているため、
# 次のセクションに進む前に、
# その表示方法について解説いたします。

# まず、白地図を作成するためには都道府県の
# 県境の位置を示すデータが必要になります。
# 国土地理院のデータを利用する方法もありますが、
# 今回は、Natural Earth(www.naturalearthdata.com/)
# のオープンデータを利用しました。
# 
# ダウンロードしたデータは、
#dataフォルダに保存してください。

# 次の動画では、このダウンロードしたデータを読み込む
# ためのパッケージのインストールと、読み込みと加工を
# 解説いたします。

##lec02:パッケージsfのインストールとデータの読み込み--------

## 地図データを取り扱うためのパッケージの
#インストール

#install.packages("sf")

#で、sfパッケージをインストールしてください。


## データの読み込み
library(tidyverse)
library(sf)

mapdata <- sf::read_sf("data/ne_10m_admin_1_states_provinces")

#簡単に読み込めました。

## データの加工

#読み込まれたデータはtibble形式なので
#tidyverse系のデータ加工が簡単に行えます

#日本のデータにだけ絞り込んでみましょう

japan <- mapdata %>% filter(adm0_a3 == 'JPN')
ita   <- mapdata %>% filter(adm0_a3 == "ITA")
#View(japan)

write_rds(japan,"japan_pref_map.rds", compress="gz")
# レポートでは、ここで保存したデータを利用しています。
# 次の動画では、このデータをどう利用するかを
# 解説しておきます。

##lec03:日本の地図の描画---------

#read_sfで読み込んだデータは、
#ggplot2::geom_sfで簡単に描画することができます。

ggplot(data = japan) + geom_sf()

#ここで、例えば、熊本県、北海道、東京都に色を付けたい場合は、

color_japan <- japan %>% 
  mutate(
    add_color = name_ja %in% 
      c("熊本県","北海道","東京都")
  )

#としてあげて、

ggplot(color_japan) + 
  geom_sf(aes(fill = add_color)) +
  theme_bw()

#とか、

ggplot(color_japan) + 
  geom_sf(aes(fill = add_color), color = "grey80") +
  scale_fill_manual(values = c("grey","red")) + 
  coord_sf(datum = NA) +
  theme_bw()

#などで簡単に色を塗ることができました。
#coord_sf等の表示方法については、本コースの
#範囲外のため、helpファイル等を参考にしてみて
#ください。

#次のセクションのレポートでは、
#都道府県別の連続値のデータをこのデータにくっつけて、
#色分けをしています

##lec04:県別に連続値で塗り分ける---------。

#この動画では、都道府県別の連続値のデータを
#japan tibbleにくっつけて、それをもとに、
#色を塗る方法について説明しておきます。

#ここでは、連続値のデータは
#ランダムな数字データをくっつけて実施するとして、

#random_numberという変数名を
#japan　tibbleにくっつけてみました。


rand_japan <- japan %>% 
  mutate(random_number = runif(n = nrow(japan), min = 0, max = 100))

runif(n=100,min=0,max=1000)

ggplot(rand_japan) + 
  geom_sf(aes(fill = random_number), 
          color = "grey80") + 
  coord_sf(datum = NA) +
  scale_fill_gradient(
    low = "white", high = "red") +
  theme_bw()

#こんな感じのグラフが出来上がります。
#駆け足でしたが、以上の事項をご理解いただいていれば
#次のセクションで作成するレポートにある
#日本地図のグラフの描画については問題なくご理解いただける
#はずです。